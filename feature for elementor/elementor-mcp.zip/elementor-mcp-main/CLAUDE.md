# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

MCP Tools for Elementor Plugin — a WordPress plugin that extends the official WordPress MCP Adapter to expose Elementor data, widgets, structures, and methods as MCP (Model Context Protocol) tools. This enables AI tools (Claude, Cursor, etc.) to create and manipulate Elementor page designs programmatically via up to 120 MCP tools (scales with environment).

## Companion projects (sibling folders, edit from here)

| Project | Path | What it is |
|---|---|---|
| **Master prompts library** | `E:\MSR Builds\Products\EMCP\prompts\` | Source-of-truth markdown files for the 50+ Premium Prompts. 10 categories (Automotive, Food & Dining, General, Health & Wellness, Home Services, Lifestyle & Entertainment, Pets, Professional Services, Retail, Weddings). Never bundled in the plugin zip. |
| **Website + docs + API** | `E:\MSR Builds\Products\EMCP\website\` | Astro 5 + Starlight + Tailwind + Postgres + Drizzle. Hosts the marketing site, comprehensive docs, and the `/api/emcp/prompts.json` license-gated endpoint the plugin's Pro Prompts page fetches from. See `website/PLAN.md` for the full implementation spec. Hosted via Dokploy at `emcp.msrbuilds.com` (planned). |

When editing premium-prompts behavior, the plugin code (`includes/admin/class-pro-prompts.php`) and the website's API endpoint (`website/src/pages/api/emcp/prompts.json.ts` per the PLAN) must stay in sync via the contract in `docs/PREMIUM_PROMPTS_API.md`.

**Current status: v1.6.0 — All phases implemented (P0/P1/P2) plus Elementor 4.0 atomic elements, top-level admin menu, and Low-tools mode.** Foundation layer, query tools, page CRUD, layout, widget, template, global, composite tools, stock images, SVG icons, custom code tools, 13 atomic element tools for Elementor 4.0+, and a curated essentials filter for clients with strict tool caps (Antigravity, Gemini API).

**Tool counts by configuration:**
- Free Elementor only: **62**
- Free Elementor + Elementor 4.0+ atomic: **76**
- With Elementor Pro: **101**
- With Elementor Pro + Elementor 4.0+: **115**
- With Elementor Pro + WooCommerce + Elementor 4.0+: **120**
- Low-tools mode (any config): capped at **51** (46 without Elementor 4.0+)
- Pro (EMCP license): **+7** SEO & Accessibility tools — registered but **disabled-by-default**, so they don't change the active surface until a user enables them on the Tools tab.

See `PLAN.md` for the full architectural specification.

## Dependencies & Requirements

- WordPress >= 6.9 (the Abilities API — `wp_register_ability()` — is core in 6.9+/7.0)
- Elementor >= 3.20 (container support required; >= 4.0 for atomic elements)
- WordPress Abilities API — core in WP 6.9+/7.0 (the only hard external dep is Elementor)
- WordPress MCP Adapter — **bundled** with the plugin since v1.7.4 (`includes/vendors/mcp-adapter/`); no separate install needed. If a standalone MCP Adapter plugin is active, the plugin defers to it (see `Elementor_MCP_Adapter_Bootstrap`).
- PHP >= 8.0

## Build & Development Commands

No external dependencies. The plugin uses WordPress core, Elementor, the core Abilities API, and a **bundled** copy of the MCP Adapter (loaded by `Elementor_MCP_Adapter_Bootstrap::ensure()` only when no standalone adapter plugin is active). Only the adapter's `includes/` source is vendored — its dev-only Composer `vendor/` is not, since the package has zero runtime dependencies.

For plugin review tooling, the `.claude/skills/wp-plugin-review/scripts/setup_tools.sh` script installs PHPCS, WPCS, PHPStan, and PHPUnit.

## Architecture

### MCP Server Registration

The plugin registers a dedicated MCP server `elementor-mcp-server` at `/wp-json/mcp/elementor-mcp-server`. All abilities use the `elementor-mcp/` namespace.

### Directory Structure

```
elementor-mcp/
├── elementor-mcp.php                          # Bootstrap: plugin header, constants, dependency checks, require_once, singleton init
├── includes/
│   ├── class-plugin.php                       # Singleton orchestrator — hooks into wp_abilities_api_categories_init, wp_abilities_api_init, mcp_adapter_init
│   ├── class-elementor-data.php               # Data access layer wrapping Elementor documents, widgets, element tree
│   ├── class-element-factory.php              # Builds valid Elementor JSON element structures (container, widget, section, column)
│   ├── class-id-generator.php                 # 7-char hex unique IDs via random_bytes()
│   ├── class-openverse-client.php             # HTTP client for Openverse image search API
│   ├── abilities/
│   │   ├── class-ability-registrar.php        # Coordinates registration of all ability groups across all phases
│   │   ├── class-query-abilities.php          # P0: 7 read-only tools (list-widgets, get-widget-schema, get-page-structure, etc.)
│   │   ├── class-page-abilities.php           # P1: 5 page CRUD tools (create-page, update-page-settings, delete-page-content, import-template, export-page)
│   │   ├── class-layout-abilities.php         # P1: 4 layout tools (add-container, move-element, remove-element, duplicate-element)
│   │   ├── class-widget-abilities.php         # P1/P2: 2 universal + 9 core + 6 Pro convenience widget tools
│   │   ├── class-template-abilities.php       # P2: 2 template tools (save-as-template, apply-template)
│   │   ├── class-global-abilities.php         # P2: 2 global tools (update-global-colors, update-global-typography)
│   │   ├── class-composite-abilities.php      # P2: 1 composite tool (build-page)
│   │   ├── class-stock-image-abilities.php    # 3 stock image tools (search-images, sideload-image, add-stock-image)
│   │   └── class-custom-code-abilities.php   # 4 custom code tools (add-custom-css, add-custom-js, add-code-snippet, list-code-snippets)
│   ├── admin/
│   │   ├── class-admin.php                    # Admin top-level menu (EMCP Tools) with 4 native submenu pages (Tools, Connection, Prompts, Changelog), stats bar, header, Low-tools mode + Pro-disabled-by-default defaults
│   │   └── views/
│   │       ├── page-tools.php                 # Tools tab: category-grouped tool toggles with bulk actions
│   │       ├── page-connection.php            # Connection tab: status cards, credential form, MCP client configs
│   │       └── page-prompts.php               # Prompts tab: sample prompt cards with one-click copy, CTA banner
│   ├── schemas/
│   │   ├── class-schema-generator.php         # Generates JSON Schema from Elementor widget controls
│   │   └── class-control-mapper.php           # Maps individual Elementor control types → JSON Schema fragments
│   └── validators/
│       ├── class-element-validator.php         # Validates element structure (id, elType, widgetType)
│       └── class-settings-validator.php        # Validates widget settings against generated schema
├── prompts/                                    # Sample landing page prompt blueprints (Markdown)
│   ├── LOCAL_BUSINESS.md
│   ├── DENTAL_CLINIC.md
│   ├── WEB_DEVELOPER_PORTFOLIO.md
│   ├── HAIR_SALON.md
│   └── CAR_WASH.md
└── tests/                                      # PHPUnit tests (not yet created)
```

### Hook Registration Flow

The plugin integrates via three WordPress hooks (in execution order):
1. **`wp_abilities_api_categories_init`** → Registers the `elementor-mcp` ability category
2. **`wp_abilities_api_init`** → Registers all abilities via `wp_register_ability()` (ability names must match `[a-z0-9-]+/[a-z0-9-]+`)
3. **`mcp_adapter_init`** → Creates MCP server via `$mcp_adapter->create_server()`, passing ability names as the tools array

The MCP Adapter converts ability names like `elementor-mcp/list-widgets` to tool names `elementor-mcp-list-widgets` (replacing `/` with `-`).

### Core Layers

1. **Data Layer** (`class-elementor-data.php`) — Read/write wrapper around `_elementor_data` post meta, widget registry, and element tree traversal. All saves go through `\Elementor\Plugin::$instance->documents->get()->save()` (never raw meta updates) to trigger CSS regeneration and cache busting.

2. **Element Factory** (`class-element-factory.php`) — Creates valid Elementor JSON structures for containers, widgets, sections, and columns. Each element gets a 7-char random hex ID.

3. **Schema Generator** (`class-schema-generator.php` + `class-control-mapper.php`) — Maps Elementor control types (TEXT, SLIDER, SELECT, MEDIA, DIMENSIONS, REPEATER, etc.) to JSON Schema. This powers the `get-widget-schema` tool that tells AI agents what settings each widget accepts.

4. **Abilities** — Grouped by domain: query (7 read-only tools), page CRUD (5), layout/container (4), widgets (16 including convenience shortcuts), templates (2), globals (2), and the composite `build-page` tool.

### Implementation Phases (from PLAN.md)

| Priority | Phase | Scope |
|----------|-------|-------|
| P0 | Foundation | Bootstrap, data layer, factory, schemas, 7 read/query tools |
| P1 | Pages & Widgets | Page CRUD (5), layout tools (4), widget tools (10+) |
| P2 | Templates & Composite | Template tools (2), global tools (2), build-page composite (1) |

### Key Design Patterns

- **Container-first**: Uses modern Elementor Container element (flexbox), not legacy Sections/Columns
- **Schema-driven validation**: Widget settings validated against auto-generated JSON schemas before saving
- **Universal + convenience**: `add-widget` works for any widget type; convenience tools (`add-heading`, `add-button`) provide simpler interfaces for common widgets
- **Pro-aware**: Pro widget tools only register when Elementor Pro is active; core tools work with free Elementor
- **`elementor_mcp_ability_names` filter** lives in `Elementor_MCP_Plugin::filter_disabled_tools()` (always loaded — NOT in the admin class, which only loads on `is_admin()`). It reads two options: `elementor_mcp_disabled_tools` (user toggles) and `elementor_mcp_low_tool_mode` (essentials-only). When low-tools mode is on, every name outside `Elementor_MCP_Plugin::get_essential_tool_slugs()` is excluded — this is the runtime path that keeps the count under client tool caps.
- **Pro widgets disabled-by-default**: on first admin page load (tracked via `elementor_mcp_defaults_applied` marker option), every Pro-badged slug from `get_all_tools()` is merged into `elementor_mcp_disabled_tools`. Users can re-enable individual Pro widgets from the Tools admin screen.

### Permission Model

| Ability Group | Required WordPress Capability |
|---------------|-------------------------------|
| Read/Query | `edit_posts` |
| Page creation | `publish_pages` or `edit_pages` |
| Widget/layout manipulation | `edit_posts` + ownership check |
| Template management | `edit_posts` |
| Global settings | `manage_options` |
| Delete operations | `delete_posts` + ownership check |
| Stock image search | `edit_posts` |
| Stock image sideload | `upload_files` |
| Stock image add | `edit_posts` + `upload_files` + ownership check |
| Custom CSS (element/page) | `edit_posts` + ownership check |
| Custom JS via HTML widget | `edit_posts` + ownership check |
| Code snippets (create) | `manage_options` + `unfiltered_html` |
| Code snippets (list) | `manage_options` |

## All Implemented Tools (up to 120 — see counts above)

### P0 — Query/Discovery (7 read-only)

| Ability Name | Purpose |
|---|---|
| `elementor-mcp/list-widgets` | All registered widget types with names, titles, icons, categories, keywords |
| `elementor-mcp/get-widget-schema` | Full JSON Schema for a widget's settings (auto-generated from Elementor controls) |
| `elementor-mcp/get-page-structure` | Element tree for a page (containers, widgets, nesting) |
| `elementor-mcp/get-element-settings` | Current settings for a specific element on a page |
| `elementor-mcp/list-pages` | All Elementor-enabled pages/posts |
| `elementor-mcp/list-templates` | Saved Elementor templates from the template library |
| `elementor-mcp/get-global-settings` | Active kit/global settings (colors, typography, spacing) |

### P1 — Page CRUD (5 tools)

| Ability Name | Purpose |
|---|---|
| `elementor-mcp/create-page` | Create a new WP page/post with Elementor enabled |
| `elementor-mcp/update-page-settings` | Update page-level Elementor settings (background, padding, etc.) |
| `elementor-mcp/delete-page-content` | Clear all Elementor content from a page (destructive) |
| `elementor-mcp/import-template` | Import JSON template structure into a page |
| `elementor-mcp/export-page` | Export page's full Elementor data as JSON |

### P1 — Layout (4 tools)

| Ability Name | Purpose |
|---|---|
| `elementor-mcp/add-container` | Add a flexbox container (top-level or nested) |
| `elementor-mcp/move-element` | Move an element to a new parent/position |
| `elementor-mcp/remove-element` | Remove an element and all children (destructive) |
| `elementor-mcp/duplicate-element` | Duplicate element with fresh IDs |

### P1/P2 — Widgets (2 universal + 23 core + 21 Pro convenience)

| Ability Name | Purpose |
|---|---|
| `elementor-mcp/add-widget` | Universal: add any widget type to a container |
| `elementor-mcp/update-widget` | Universal: update settings on an existing widget |
| `elementor-mcp/add-heading` | Convenience: heading widget |
| `elementor-mcp/add-text-editor` | Convenience: rich text editor widget |
| `elementor-mcp/add-image` | Convenience: image widget |
| `elementor-mcp/add-button` | Convenience: button widget |
| `elementor-mcp/add-video` | Convenience: video widget |
| `elementor-mcp/add-icon` | Convenience: icon widget |
| `elementor-mcp/add-spacer` | Convenience: spacer widget |
| `elementor-mcp/add-divider` | Convenience: divider widget |
| `elementor-mcp/add-icon-box` | Convenience: icon box widget |
| `elementor-mcp/add-accordion` | Convenience: collapsible accordion widget |
| `elementor-mcp/add-alert` | Convenience: alert/notice widget |
| `elementor-mcp/add-counter` | Convenience: animated counter widget |
| `elementor-mcp/add-google-maps` | Convenience: embedded Google Maps widget |
| `elementor-mcp/add-icon-list` | Convenience: icon list for features/checklists |
| `elementor-mcp/add-image-box` | Convenience: image box (image + title + description) |
| `elementor-mcp/add-image-carousel` | Convenience: rotating image carousel |
| `elementor-mcp/add-progress` | Convenience: animated progress bar |
| `elementor-mcp/add-social-icons` | Convenience: social media icon links |
| `elementor-mcp/add-star-rating` | Convenience: star rating display |
| `elementor-mcp/add-tabs` | Convenience: tabbed content widget |
| `elementor-mcp/add-testimonial` | Convenience: testimonial with quote and author |
| `elementor-mcp/add-toggle` | Convenience: toggle/expandable content |
| `elementor-mcp/add-html` | Convenience: custom HTML code widget |
| `elementor-mcp/add-form` | Pro: form widget |
| `elementor-mcp/add-posts-grid` | Pro: posts grid widget |
| `elementor-mcp/add-countdown` | Pro: countdown timer widget |
| `elementor-mcp/add-price-table` | Pro: price table widget |
| `elementor-mcp/add-flip-box` | Pro: flip box widget |
| `elementor-mcp/add-animated-headline` | Pro: animated headline widget |
| `elementor-mcp/add-call-to-action` | Pro: call-to-action widget |
| `elementor-mcp/add-slides` | Pro: full-width slides/slider |
| `elementor-mcp/add-testimonial-carousel` | Pro: testimonial carousel/slider |
| `elementor-mcp/add-price-list` | Pro: price list for menus/services |
| `elementor-mcp/add-gallery` | Pro: advanced gallery (grid/masonry/justified) |
| `elementor-mcp/add-share-buttons` | Pro: social share buttons |
| `elementor-mcp/add-table-of-contents` | Pro: auto-generated table of contents |
| `elementor-mcp/add-blockquote` | Pro: styled blockquote widget |
| `elementor-mcp/add-lottie` | Pro: Lottie animation widget |
| `elementor-mcp/add-hotspot` | Pro: image hotspot widget |
| `elementor-mcp/add-code-highlight` | Pro: syntax-highlighted code block widget |
| `elementor-mcp/add-reviews` | Pro: reviews/testimonials carousel widget |
| `elementor-mcp/add-off-canvas` | Pro: off-canvas panel widget |
| `elementor-mcp/add-progress-tracker` | Pro: scroll progress tracker widget |
| `elementor-mcp/add-search` | Pro: search widget with live results support |

### P2 — Templates (2 tools)

| Ability Name | Purpose |
|---|---|
| `elementor-mcp/save-as-template` | Save a page or element as reusable template |
| `elementor-mcp/apply-template` | Apply a saved template to a page |

### P2 — Global Settings (2 tools)

| Ability Name | Purpose |
|---|---|
| `elementor-mcp/update-global-colors` | Update site-wide color palette in Elementor kit |
| `elementor-mcp/update-global-typography` | Update site-wide typography in Elementor kit |

### P2 — Composite (1 tool)

| Ability Name | Purpose |
|---|---|
| `elementor-mcp/build-page` | Create complete page from declarative structure in one call |

### Media Library (1 tool)

| Ability Name | Purpose |
|---|---|
| `elementor-mcp/list-media` | List/search images already in the WordPress Media Library (the site's own uploads). Optional `search` matches title, alt text, caption, and description; `mime_type` / pagination / sort filters. Read-only WP_Query, no HTTP. ([#25](https://github.com/msrbuilds/elementor-mcp/issues/25)) |

### Stock Images (3 tools)

| Ability Name | Purpose |
|---|---|
| `elementor-mcp/search-images` | Search Openverse (WordPress.org) for Creative Commons images by keyword |
| `elementor-mcp/sideload-image` | Download an external image URL into the WordPress Media Library |
| `elementor-mcp/add-stock-image` | Search + sideload + add image widget to page in one call |

### Custom Code (4 tools)

| Ability Name | Purpose |
|---|---|
| `elementor-mcp/add-custom-css` | Add custom CSS to a specific element or page-level (Pro only, uses `selector` keyword) |
| `elementor-mcp/add-custom-js` | Add JavaScript to a page via HTML widget with auto `<script>` wrapping |
| `elementor-mcp/add-code-snippet` | Create a site-wide Custom Code snippet for head/body injection (Pro only) |
| `elementor-mcp/list-code-snippets` | List existing Custom Code snippets with locations and statuses (Pro only) |

### PHP Snippets — Sandbox (6 tools, FREE, off by default)

Free but capability-gated and powerful, so all six are **disabled-by-default** (the `php_snippets` category in `get_all_tools()`; the v4 defaults marker seeds them via `EMCP_Tools_Admin::php_snippet_tool_slugs()`). The whole point is the **human approval gate**: AI can author + validate **drafts**, but there is **no activate tool** — only an admin can activate a snippet (in EMCP Tools → Sandbox), which is the only way it ever executes. Write tools require `manage_options` + `unfiltered_html`; reads require `manage_options`.

- `EMCP_Tools_PHP_Snippet_Validator` (`includes/class-php-snippet-validator.php`) — parse check (`token_get_all(…, TOKEN_PARSE)`) + token-walk security scan. CRITICAL findings block create/activate (exec/eval/backtick/variable-functions/file-writes/network/obfuscation-decoders/destructive-SQL/dynamic-include); WARNING findings are surfaced to the reviewer. Static analysis is a guardrail, not a guarantee.
- `EMCP_Tools_PHP_Snippet_Store` (`includes/class-php-snippet-store.php`) — `emcp_php_snippet` CPT + sandbox (`uploads/emcp-widgets/snippets/{id}.php`, `.htaccess`-blocked). Drafts have **no executable file**; activation wraps the code in `emcp_php_snippet_{id}()`, writes it, records a sha256 manifest entry.
- `EMCP_Tools_PHP_Snippet_Loader` (`includes/class-php-snippet-loader.php`) — manifest-only, hash-verified include; runs ACTIVE snippets on their hook and/or via `[emcp_snippet id="N"]`, inside try/catch + a `register_shutdown_function` that auto-deactivates a snippet that fatals.

| Ability Name | Purpose |
|---|---|
| `elementor-mcp/validate-php-snippet` | Static parse + security scan of code; no store, no run. Returns critical/warning findings |
| `elementor-mcp/create-php-snippet` | Create an **inactive draft** (validated; critical = rejected). Never runs until an admin activates it |
| `elementor-mcp/update-php-snippet` | Update a snippet's code/settings; re-validates |
| `elementor-mcp/get-php-snippet` | Return code, status, shortcode, and validation report |
| `elementor-mcp/list-php-snippets` | List snippets with status and run context |
| `elementor-mcp/delete-php-snippet` | Delete a snippet and its sandbox file |

### SEO & Accessibility Toolkit — Pro (7 tools, off by default)

Pro-only, registered only when `emcp_pro_fs()->can_use_premium_code()` (self-guarded like the brand-kit tools). All seven are **disabled-by-default** (the `seo_a11y` category in `get_all_tools()` carries the `pro` badge; the v2 defaults marker in `maybe_apply_default_disabled_tools()` seeds them into `elementor_mcp_disabled_tools` on upgrade — `Elementor_MCP_Admin::seo_a11y_tool_slugs()` is the canonical list). Users re-enable individual tools on the Tools tab. No external API — pure PHP over the Elementor data layer + SEO-plugin meta. The five audits/generators are **read-only**; the two fixers **mutate only when `apply: true`** (dry-run preview by default) and are reversible via Elementor revisions. Shared helpers: `Elementor_MCP_Content_Extractor` (normalized page view), `Elementor_MCP_Color_Contrast` (WCAG math), `Elementor_MCP_Seo_Meta` (Yoast/Rank Math/core).

| Ability Name | Purpose |
|---|---|
| `elementor-mcp/audit-page-seo` | Scored on-page SEO report: H1 presence, title/meta length, canonical, heading hierarchy, image alts, internal links, word count, optional target-keyword usage |
| `elementor-mcp/extract-keywords-from-content` | Frequency/TF-IDF-style keyword + bigram extraction from page text (stop-word filtered, no external service) |
| `elementor-mcp/generate-meta-tags` | Proposes an SEO title (≤60) + meta description (≤155) from page content, keyword-front-loaded; proposal-only |
| `elementor-mcp/generate-schema-markup` | Generates JSON-LD (Article / LocalBusiness / FAQPage / Service / Product); LocalBusiness takes a `business` object, FAQPage a `faqs` array; proposal-only |
| `elementor-mcp/audit-page-a11y` | WCAG-oriented report: color contrast (best-effort, `inconclusive` when background unresolved), missing alts, heading order, generic/empty link text, form-label coverage |
| `elementor-mcp/fix-color-contrast` | Proposes (and with `apply:true` writes) adjusted text colors so failing pairs meet WCAG AA. Dry-run by default; writes the resolved `*_color` setting via the data layer |
| `elementor-mcp/add-alt-text-from-context` | Proposes (and with `apply:true` writes) alt text for images lacking it, derived from filename → nearest heading → page title. Dry-run by default; writes `_wp_attachment_image_alt` + the image widget's alt |

### Atomic Elements — Elementor 4.0+ (13 tools)

These tools only register when Elementor >= 4.0 is detected. Legacy tools continue to work alongside them.

**Atomic elements use a typed props system (`$$type` wrappers) and a separate `styles` map for visual styling. The convenience tools handle this automatically — AI agents pass simple flat values.**

| Ability Name | Purpose |
|---|---|
| `elementor-mcp/detect-elementor-version` | Returns Elementor version and whether atomic elements are supported. Call first to choose tool family. |
| `elementor-mcp/add-atomic-widget` | Universal: add any atomic widget by type name with raw $$type settings |
| `elementor-mcp/update-atomic-widget` | Universal: partial-merge update on an existing atomic widget's settings |
| `elementor-mcp/add-atomic-heading` | Convenience: atomic heading (e-heading). Params: title, tag (h1-h6), link, css_id |
| `elementor-mcp/add-atomic-paragraph` | Convenience: atomic paragraph (e-paragraph). Params: content, link, css_id |
| `elementor-mcp/add-atomic-button` | Convenience: atomic button (e-button). Params: text, link, target_blank, css_id |
| `elementor-mcp/add-atomic-image` | Convenience: atomic image (e-image). Params: image_id, image_url, alt, link, css_id |
| `elementor-mcp/add-atomic-svg` | Convenience: atomic SVG (e-svg). Params: svg_id, svg_url, css_id |
| `elementor-mcp/add-atomic-youtube` | Convenience: atomic YouTube embed (e-youtube). Params: video_url, css_id |
| `elementor-mcp/add-atomic-video` | Convenience: atomic self-hosted video (e-self-hosted-video). Params: video_url, video_id, css_id |
| `elementor-mcp/add-atomic-divider` | Convenience: atomic divider (e-divider). Params: css_id |
| `elementor-mcp/add-flexbox` | Atomic flexbox container (e-flexbox). Params: direction, justify, align, gap, wrap, tag, padding, background_color |
| `elementor-mcp/add-div-block` | Atomic div-block container (e-div-block). Params: tag, padding, background_color |

### Global Classes — Class Manager (1 tool, Elementor 4.0+)

Registers only when Elementor's `Global_Classes_Repository` exists (Elementor 4.0+). Read-only (`edit_posts`); resolves the `g-` style IDs applied to elements. Implemented in `includes/abilities/class-global-classes-abilities.php`; uses Elementor's own repository + `EMCP_Tools_Atomic_Props::unwrap()` to flatten the `$$type` CSS props. ([#55](https://github.com/msrbuilds/elementor-mcp/issues/55))

| Ability Name | Purpose |
|---|---|
| `elementor-mcp/list-global-classes` | Map Class Manager `g-` IDs → human label + CSS properties (per breakpoint/state). Optional `class_ids` filter; omit for all. |

### Atomic Element Data Model (Elementor 4.0+)

Atomic elements have a different JSON structure from legacy widgets:

- **`settings`** contains content props using `$$type` wrappers: `{ "tag": { "$$type": "string", "value": "h2" } }`
- **`styles`** (sibling of settings) contains visual/layout CSS using local style classes
- **`interactions`** (sibling) stores entrance/hover/click interactions
- Style properties use CSS property names (kebab-case): `flex-direction`, `justify-content`, `gap`
- Layout props are NOT in settings — they're in `styles[class_id].variants[].props`

### Key Architecture Files (Atomic)

| File | Purpose |
|---|---|
| `includes/class-atomic-props.php` | Static helpers to wrap/unwrap $$type values |
| `includes/class-atomic-styles.php` | Builds local style classes for flex layout, spacing, colors |
| `includes/abilities/class-atomic-widget-abilities.php` | 10 atomic widget tools |
| `includes/abilities/class-atomic-layout-abilities.php` | 2 container tools + detect-version |

## Connecting to the MCP Server

### Prerequisites

- WordPress with Elementor + MCP Adapter + MCP Tools for Elementor all active
- One of: WP-CLI (for local) or Node.js 18+ (for remote/proxy)
- A WordPress Application Password (Users > Profile > Application Passwords)

### Option A: WP-CLI stdio (local dev, recommended)

The MCP Adapter includes a built-in WP-CLI stdio bridge. No HTTP round-trip, no sessions, no auth config needed.

**Claude Code** (`.mcp.json` already in project root):
```json
{
  "mcpServers": {
    "elementor-mcp": {
      "type": "stdio",
      "command": "wp",
      "args": ["mcp-adapter", "serve", "--server=elementor-mcp-server", "--user=admin", "--path=/path/to/wordpress"]
    }
  }
}
```

**Claude Desktop** (add to `%APPDATA%\Claude\claude_desktop_config.json`):
```json
{
  "mcpServers": {
    "elementor-mcp": {
      "command": "wp",
      "args": ["mcp-adapter", "serve", "--server=elementor-mcp-server", "--user=admin", "--path=/path/to/wordpress"]
    }
  }
}
```

**Verify:** `wp mcp-adapter list --path=/path/to/wordpress` should show `elementor-mcp-server`.

### Option B: Node.js proxy (remote sites)

For remote WordPress sites or environments without WP-CLI, use the Node.js proxy. It bridges stdio ↔ WordPress HTTP endpoint with Application Password auth. **The client launches it as a local subprocess, so it must run on the client machine, not the server** — on shared hosting there's no local access to `wp-content/plugins/...`. Two ways to run it:

**Recommended — npx runner** (`@msrbuilds/emcp-proxy`, published from `bin/` — see [bin/package.json](bin/package.json)). Nothing to copy or keep in sync:

```json
{
  "mcpServers": {
    "elementor-mcp": {
      "command": "npx",
      "args": ["-y", "@msrbuilds/emcp-proxy@latest"],
      "env": {
        "WP_URL": "https://your-site.com",
        "WP_USERNAME": "admin",
        "WP_APP_PASSWORD": "xxxx xxxx xxxx xxxx xxxx xxxx",
        "MCP_PROTOCOL_VERSION": "2024-11-05"
      }
    }
  }
}
```

**Alternative — local copy:** extract `bin/mcp-proxy.mjs` from the ZIP to the client machine and point `args` at that local path (`["C:\\local\\path\\to\\mcp-proxy.mjs"]`). For local dev from the plugin dir, `["bin/mcp-proxy.mjs"]` works since client and server share the filesystem.

`MCP_PROTOCOL_VERSION=2024-11-05` makes the proxy rewrite the adapter's `2025-06-18` handshake for clients that reject it (e.g. some Claude Desktop builds).

### Option C: Direct HTTP (VS Code MCP extension)

```json
{
  "servers": {
    "elementor-mcp": {
      "type": "http",
      "url": "https://your-site.com/wp-json/mcp/elementor-mcp-server",
      "headers": {
        "Authorization": "Basic BASE64_ENCODED_CREDENTIALS"
      }
    }
  }
}
```

### Testing with MCP Inspector

```bash
npx @modelcontextprotocol/inspector wp mcp-adapter serve --server=elementor-mcp-server --user=admin --path=/path/to/wordpress
```

### Troubleshooting

- **"No MCP servers registered"**: Ensure MCP Tools for Elementor plugin is active and dependencies are met
- **HTTP 401**: Check Application Password is correct and user has `edit_posts` capability
- **Session errors**: The HTTP endpoint requires `Mcp-Session-Id` header after `initialize`; the proxy handles this automatically
- **WP-CLI not found on Windows**: Use full path to `php.exe` and `wp-cli.phar`

See `mcp-config-examples.json` for copy-paste configs for all supported clients.

## WordPress Plugin Conventions

This project follows the patterns defined in `.claude/skills/wp-plugin-dev/`:

- **Bootstrap file is minimal** — `elementor-mcp.php` contains only plugin header, constants, dependency checks, `require_once` statements, and singleton init. No feature logic.
- **WordPress naming**: `snake_case` for functions/variables, `Upper_Snake_Case` for classes, `UPPER_SNAKE` for constants
- **Prefix everything**: All functions, classes, hooks, options use the plugin prefix
- **All strings translatable** using `__()`, `_e()`, `esc_html__()`, etc.
- **Security is non-negotiable**: Sanitize all input (`sanitize_text_field`, `absint`, etc.), escape all output (`esc_html`, `esc_attr`, `esc_url`), use `$wpdb->prepare()` for SQL, verify nonces on forms/AJAX, check capabilities before privileged operations
- **Enqueue assets properly** via `wp_enqueue_script()`/`wp_enqueue_style()`, never hardcode tags
- **GPL-2.0-or-later** license required

## Claude Skills Available

Two custom skills are configured in `.claude/skills/`:

- **wp-plugin-dev** — Scaffolding and building WordPress plugins following WP coding standards. Has reference docs for architecture patterns, security functions, and WP.org guidelines.
- **wp-plugin-review** — Automated + manual plugin review (PHPCS/WPCS, PHPStan, PHPUnit, security audit, accessibility). Produces a structured Markdown report.
